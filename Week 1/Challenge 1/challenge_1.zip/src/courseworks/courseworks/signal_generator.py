#Importamos las librerías
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
import math #Necesaria para la función seno

class My_Publisher(Node):
    def __init__(self):
        #Creamos un nodo con el nombre 'signal_generator': 
        super().__init__('signal_generator') 
        #Creamos un publicador al tópico 'signal' por el cual mandaremos la señal senoidal: 
        self.signal = self.create_publisher(Float32, 'signal', 10)
        #Creamos un publicador al topico 'time' por donde mandaremos el tiempo transcurrido: 
        self.time = self.create_publisher(Float32, 'time', 10)
        #Creamos un  periodo de timer de 0.1s, ya que deseamos alcanzar una frecuencia de 10Hz: 
        timer_period = 0.1 
        #Creamos el timer, asignando el periodo previamente creado e indicando que la función 
        #timer_callback será la que se llame cada timer_period: 
        self.timer = self.create_timer(timer_period, self.timer_callback)
        #Agregamos un pequeño logger o mensaje, que se imprimirá en terminal cuando el nodo se inicialice: 
        self.get_logger().info('Signal generator node successfully initialized!!')
        #Creamos las variables donde almacenaremos los datos que se enviaran por los tópicos
        self.time_msg = Float32()
        self.signal_msg = Float32()
        
        
    def timer_callback(self):
    #Obtenemos el tiempo transcurrido: 
        t = self.get_clock().now().nanoseconds / 1e9
    #Asignamos el tiempo a la variable correspondiente: 
        self.time_msg.data = t
        #Calculamos el seno del tiempo actual y lo asignamos a la variable signal_msg: 
        self.signal_msg.data = math.sin(t)
    #Publicamos/mandamos los mensajes por su tópico correspondiente: 
        self.time.publish(self.time_msg)
        self.signal.publish(self.signal_msg)
        #Agregamos un logger para imprimir los datos en terminal: 
        self.get_logger().info(f"Time: {self.time_msg.data}, Signal: {self.signal_msg.data}")


def main(args=None):
    #Inicializamos rclpy, necesario para trabajar con nodos: 
    rclpy.init(args=args)
    #Instanciamos un objeto de nuestro publicador (signal_generator): 
    m_p = My_Publisher()
    #Indicamos que se ejecute en un loop: 
    rclpy.spin(m_p)
    #Tras haber una interrupción en la ejecución del nodo, lo destruimos para liberar recursos: 
    m_p.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

