#Importamos las librerías correspondientes
import rclpy 
from rclpy.node import Node
from std_msgs.msg import Float32, String

class My_Subscriber(Node):
    def __init__(self):
        #Creamos un nodo con el nombre 'signal_generator': 
        super().__init__('process')
        #Creamos subscripciones a los tópicos 'time' y 'signal' para recibir los datos correspondientes: 
        self.subTime = self.create_subscription(Float32, '/time', self.time_callback, 10)
        self.subSignal = self.create_subscription(Float32, '/signal', self.signal_callback, 10)
        #Creamos un publicador al tópico 'proc_signal', por donde mandaremos la señal modificada:
        self.pub_proc_signal = self.create_publisher(Float32, 'proc_signal', 10)
        #Agregamos un logger para indicar la correcta inicialización del nodo y 
        #notificar que se ha suscrito a los tópicos 'time' y 'signal':
        self.get_logger().info('Process subscribed to /time and /signal topics!!!')
        #Creamos la variable donde almacenaremos el valor de la señal modificada:
        self.modified_signal_msg = Float32()

    def signal_callback(self, signal_msg):
        #Con un logger, imprimimos en terminal cada vez que se reciba un valor en el tópico 'signal':
        self.get_logger().info(f"Received Signal: {signal_msg.data}")
        # Modificamos la señal recibida, duplicándola:
        self.modified_signal_msg.data = signal_msg.data * 2  
        # Publicamos la señal modificada en el tópico  correspondiente:
        self.pub_proc_signal.publish(self.modified_signal_msg)
    
    def time_callback(self, time_msg):
        #Con un logger, imprimimos en terminal cada vez que se reciba un valor en el tópico 'time':
        self.get_logger().info(f"Received Time: {time_msg.data}")

def main(args=None):
    #Inicializamos rclpy, necesario para trabajar con nodos;:
    rclpy.init(args=args)
    #Instanciamos un objeto de nuestro subscritor: 
    m_s= My_Subscriber()
    #Indicamos que se ejecute en un loop: 
    rclpy.spin(m_s)
    #Tras haber una interrupción en la ejecución del nodo, lo destruimos para liberar recursos: 
    m_s.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()