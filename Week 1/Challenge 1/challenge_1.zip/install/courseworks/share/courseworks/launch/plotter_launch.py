#Importamos las librerías correspondientes
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
   return LaunchDescription([
       #Inicializamos el nodo signal_generator del paquete courseworks
       Node( 
           package='courseworks', 
           executable='signal_generator',
           output = 'screen',
           prefix='gnome-terminal --' #Indicamos al sistema que inicié el nodo en una nueva terminal
       ),
       #Inicializamos el nodo process del paquete courseworks
       Node(
           package='courseworks',
           executable='process',
           output = 'screen',
           prefix='gnome-terminal --' #Indicamos al sistema que inicié el nodo en una nueva terminal
       ),
       #En una nueva terminal, ejecutamos rqt_graph para visualizar los nodos y tópicos activos
       Node(
           package = 'rqt_graph',
           executable = 'rqt_graph',
           prefix='gnome-terminal --' 
       ),
       #Ejecutamos rqt_plot para visualizar gráficamente los datos de la señal original y la modificada
       Node(
           package = 'rqt_plot',
           executable = 'rqt_plot',
           arguments= ['/signal/data', '/proc_signal/data'] #Indicamos específicamente qué datos deseamos graficar
       )
   ])
   
'''OBSERVACIÓN: La ejecución de esto se realiza de la siguiente manera: 
     ros2 run package executable 
     Esto lo podemos aprovechar para ejecutar otros comandos, tal como se hizo con rqt_graph y rqt_plot '''