import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description(): 

    #Dirección al archivo params.yaml
    config = os.path.join(
        get_package_share_directory('signals_params'), 
                                    'config',
                                    'params.yaml')

    #Nodo signal_generator: 
    signal_generator = Node(
        package='signals_params',
        executable='signal_generator',
        output='screen',
        prefix = 'gnome-terminal --', #Ejecutamos en otra terminal
        parameters=[config] #Inicializamos los parametros con los valores del archivo .yaml
    )

    #Nodo reconstructor
    reconstructor = Node(
        package='signals_params',
        executable='reconstructor', 
        output = 'screen', 
        prefix = 'gnome-terminal --' #Ejecutamos en otra terminal               
    )

    #Lanzamos rqt_plot para graficar las señales
    rqt_plot = Node(
        package='rqt_plot', 
        executable='rqt_plot', 
        output = 'screen', 
        parameters=['/signal/data', '/signal_reconstructed/data']   
    )

    #Lanzamos rqt_graph para graficar los nodos y topicos
    rqt_graph = Node(
        package='rqt_graph', 
        executable='rqt_graph', 
        output = 'screen', 
    )
    

    l_d = LaunchDescription([signal_generator, reconstructor, rqt_plot, rqt_graph])
    return l_d