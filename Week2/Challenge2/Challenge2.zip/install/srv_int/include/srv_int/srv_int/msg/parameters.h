// generated from rosidl_generator_c/resource/idl.h.em
// with input from srv_int:msg/Parameters.idl
// generated code does not contain a copyright notice

#ifndef SRV_INT__MSG__PARAMETERS_H_
#define SRV_INT__MSG__PARAMETERS_H_

#include "srv_int/msg/detail/parameters__struct.h"
#include "srv_int/msg/detail/parameters__functions.h"
#include "srv_int/msg/detail/parameters__type_support.h"

#endif  // SRV_INT__MSG__PARAMETERS_H_
