// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from srv_int:msg/Parameters.idl
// generated code does not contain a copyright notice

#ifndef SRV_INT__MSG__DETAIL__PARAMETERS__TRAITS_HPP_
#define SRV_INT__MSG__DETAIL__PARAMETERS__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "srv_int/msg/detail/parameters__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace srv_int
{

namespace msg
{

inline void to_flow_style_yaml(
  const Parameters & msg,
  std::ostream & out)
{
  out << "{";
  // member: type
  {
    out << "type: ";
    rosidl_generator_traits::value_to_yaml(msg.type, out);
    out << ", ";
  }

  // member: frequency
  {
    out << "frequency: ";
    rosidl_generator_traits::value_to_yaml(msg.frequency, out);
    out << ", ";
  }

  // member: offset
  {
    out << "offset: ";
    rosidl_generator_traits::value_to_yaml(msg.offset, out);
    out << ", ";
  }

  // member: time
  {
    out << "time: ";
    rosidl_generator_traits::value_to_yaml(msg.time, out);
    out << ", ";
  }

  // member: phase_shift
  {
    out << "phase_shift: ";
    rosidl_generator_traits::value_to_yaml(msg.phase_shift, out);
    out << ", ";
  }

  // member: amplitude
  {
    out << "amplitude: ";
    rosidl_generator_traits::value_to_yaml(msg.amplitude, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Parameters & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "type: ";
    rosidl_generator_traits::value_to_yaml(msg.type, out);
    out << "\n";
  }

  // member: frequency
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "frequency: ";
    rosidl_generator_traits::value_to_yaml(msg.frequency, out);
    out << "\n";
  }

  // member: offset
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "offset: ";
    rosidl_generator_traits::value_to_yaml(msg.offset, out);
    out << "\n";
  }

  // member: time
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "time: ";
    rosidl_generator_traits::value_to_yaml(msg.time, out);
    out << "\n";
  }

  // member: phase_shift
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "phase_shift: ";
    rosidl_generator_traits::value_to_yaml(msg.phase_shift, out);
    out << "\n";
  }

  // member: amplitude
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "amplitude: ";
    rosidl_generator_traits::value_to_yaml(msg.amplitude, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Parameters & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace srv_int

namespace rosidl_generator_traits
{

[[deprecated("use srv_int::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const srv_int::msg::Parameters & msg,
  std::ostream & out, size_t indentation = 0)
{
  srv_int::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use srv_int::msg::to_yaml() instead")]]
inline std::string to_yaml(const srv_int::msg::Parameters & msg)
{
  return srv_int::msg::to_yaml(msg);
}

template<>
inline const char * data_type<srv_int::msg::Parameters>()
{
  return "srv_int::msg::Parameters";
}

template<>
inline const char * name<srv_int::msg::Parameters>()
{
  return "srv_int/msg/Parameters";
}

template<>
struct has_fixed_size<srv_int::msg::Parameters>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<srv_int::msg::Parameters>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<srv_int::msg::Parameters>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // SRV_INT__MSG__DETAIL__PARAMETERS__TRAITS_HPP_
