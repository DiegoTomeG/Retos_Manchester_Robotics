// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from srv_int:msg/Parameters.idl
// generated code does not contain a copyright notice

#ifndef SRV_INT__MSG__DETAIL__PARAMETERS__BUILDER_HPP_
#define SRV_INT__MSG__DETAIL__PARAMETERS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "srv_int/msg/detail/parameters__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace srv_int
{

namespace msg
{

namespace builder
{

class Init_Parameters_amplitude
{
public:
  explicit Init_Parameters_amplitude(::srv_int::msg::Parameters & msg)
  : msg_(msg)
  {}
  ::srv_int::msg::Parameters amplitude(::srv_int::msg::Parameters::_amplitude_type arg)
  {
    msg_.amplitude = std::move(arg);
    return std::move(msg_);
  }

private:
  ::srv_int::msg::Parameters msg_;
};

class Init_Parameters_phase_shift
{
public:
  explicit Init_Parameters_phase_shift(::srv_int::msg::Parameters & msg)
  : msg_(msg)
  {}
  Init_Parameters_amplitude phase_shift(::srv_int::msg::Parameters::_phase_shift_type arg)
  {
    msg_.phase_shift = std::move(arg);
    return Init_Parameters_amplitude(msg_);
  }

private:
  ::srv_int::msg::Parameters msg_;
};

class Init_Parameters_time
{
public:
  explicit Init_Parameters_time(::srv_int::msg::Parameters & msg)
  : msg_(msg)
  {}
  Init_Parameters_phase_shift time(::srv_int::msg::Parameters::_time_type arg)
  {
    msg_.time = std::move(arg);
    return Init_Parameters_phase_shift(msg_);
  }

private:
  ::srv_int::msg::Parameters msg_;
};

class Init_Parameters_offset
{
public:
  explicit Init_Parameters_offset(::srv_int::msg::Parameters & msg)
  : msg_(msg)
  {}
  Init_Parameters_time offset(::srv_int::msg::Parameters::_offset_type arg)
  {
    msg_.offset = std::move(arg);
    return Init_Parameters_time(msg_);
  }

private:
  ::srv_int::msg::Parameters msg_;
};

class Init_Parameters_frequency
{
public:
  explicit Init_Parameters_frequency(::srv_int::msg::Parameters & msg)
  : msg_(msg)
  {}
  Init_Parameters_offset frequency(::srv_int::msg::Parameters::_frequency_type arg)
  {
    msg_.frequency = std::move(arg);
    return Init_Parameters_offset(msg_);
  }

private:
  ::srv_int::msg::Parameters msg_;
};

class Init_Parameters_type
{
public:
  Init_Parameters_type()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Parameters_frequency type(::srv_int::msg::Parameters::_type_type arg)
  {
    msg_.type = std::move(arg);
    return Init_Parameters_frequency(msg_);
  }

private:
  ::srv_int::msg::Parameters msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::srv_int::msg::Parameters>()
{
  return srv_int::msg::builder::Init_Parameters_type();
}

}  // namespace srv_int

#endif  // SRV_INT__MSG__DETAIL__PARAMETERS__BUILDER_HPP_
