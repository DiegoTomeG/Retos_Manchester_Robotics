import rclpy
import numpy as np
from scipy import signal
from rclpy.node import Node
from std_msgs.msg import Float32
import time
from srv_int.msg import Parameters #Importado del paquete creado srv_int

class Signal_Reconstructor(Node): 
    def __init__(self): 
        super().__init__('reconstruction')
        #Creamos una subscripción al topico signal_params
        self.subscription = self.create_subscription(Parameters,'signal_params',self.reconstruction_callback,10)

        #Variables para la señal reconstruida (valores que influyen en el calculo de la señal)
        self.type = 0
        self.frequency = 0.0
        self.offset = 0.0
        self.time_susctraction = 0.0
        self.phase_shift = 0.0
        self.amplitude = 0.0

        #Publicador para la señal reconstruida. 
        self.publisher = self.create_publisher(Float32,'signal_reconstrudted',10)
        timer_period = 0.001 #Señal reconstruida publicada a 1 khz
        
        #Timer para publicar la señal reconstruida
        self.timer = self.create_timer(timer_period, self.reconstructed_signal)
        #Variable para almacenar la señal reconstruida
        self.signal_value = Float32()

        #Mensaje de inicialización 
        self.get_logger().info("Singal reconstructor succesfully initialized !")


    def reconstruction_callback(self, msg): 
        #Cada que se reciba un mensaje por el topico signal_params, copiamos los parametros en las
        #variables del nodo
        self.type = msg.type
        self.frequency = msg.frequency
        self.offset = msg.offset
        self.time_subtraction= time.time() - msg.time
        self.phase_shift = msg.phase_shift
        self.amplitude = msg.amplitude

        '''
        La variable time_subtraction se implementa en caso de haber variación en el tiempo para cada uno de los nodos. Implementando esta variable 
        nos aseguramos que no haya un desfase en la señal (al menos que el parametro phase_shift afecte en el comportamiento)
        '''

    def reconstructed_signal(self): 
        #Reconstruimos la señal considerando los parametros recibidos del topico signal_params: 
        t = time.time()
        argument = 2*np.pi*self.frequency*(t-self.time_susctraction)+self.phase_shift
        if (self.type == 1): #Sine
            self.signal_value.data = self.amplitude*np.sin(argument) + self.offset
        elif(self.type == 2): #Square
            self.signal_value.data = self.amplitude*float(signal.square(argument))+ self.offset
        elif(self.type == 3): #Sawtooth
            self.signal_value.data = self.amplitude*float(signal.sawtooth(argument))+ self.offset
        elif(self.type == 4): #Triangle
            self.signal_value.data = self.amplitude*float(signal.sawtooth(argument, width=0.5))+self.offset
        elif(self.type == 5): #Cos
            self.signal_value.data = self.amplitude*np.cos(argument) + self.offset

        #Mostramos el valor de la señal reconstruida: 
        self.get_logger().info(f"Value: {self.signal_value.data}")
        #Publicamos la señal reconstruida
        self.publisher.publish(self.signal_value)


def main(): 
    #Ejecución del nodo
    rclpy.init()
    s_r = Signal_Reconstructor()
    rclpy.spin(s_r)
    s_r.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__': 
    main()