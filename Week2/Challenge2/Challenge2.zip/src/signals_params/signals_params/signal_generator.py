import rclpy
import numpy as np
import time 
from scipy import signal
from rclpy.node import Node
from std_msgs.msg import Float32
from srv_int.msg import Parameters #Importado del paquete creado srv_int

class Signal_Generator(Node): 
    def __init__(self): 
        super().__init__('signal_generator_node') #El nombre del nodo debe coincidir con el declarado en el archivo .yaml
        self.declare_parameters(
            namespace='', 
            parameters=[ #Declaramos los parametros (Deben tener el mismo nombre al del archivo .yaml)
                ('selection', rclpy.Parameter.Type.INTEGER), ('amplitude_array', rclpy.Parameter.Type.DOUBLE_ARRAY),
                ('frequency_array', rclpy.Parameter.Type.DOUBLE_ARRAY),('offset_array', rclpy.Parameter.Type.DOUBLE_ARRAY),
                ('phase_shift', rclpy.Parameter.Type.DOUBLE_ARRAY)
            ]
        )

        #Publicador para la señal calculada: 
        self.signal_pub = self.create_publisher(Float32, 'signal', 10)
        signal_period = 0.001 #Señal publicada a 1KHz

        #Timer para publicar la señal: 
        self.timer_signal = self.create_timer(signal_period, self.signal_callback)
        #Variable de la señal
        self.signal_value = Float32()

        #Publicador para los parametros de la señal (Tipo de dato: Parameters)
        self.parameters_pub = self.create_publisher(Parameters, 'signal_params', 10)
        parameters_period = 0.1 #10hz
        
        #Timer para publicar los parametros
        self.timer_parms = self.create_timer(parameters_period, self.send_parameters)
        #Variable tipo Parameters
        self.parameters_values = Parameters()
    
        #Mensaje de inicialización 
        self.get_logger().info("Singal generator succesfully initialized !")

    def signal_callback(self): 
        #Obtenemos la selección de la señal : 
        selection = self.get_parameter('selection').get_parameter_value().integer_value

        if(selection>5 or selection<=0): 
            selection = 1 #Si se modifica el parametro, asegurarse que este dentro del rango

        #Parametros para la señal: 
        amplitude = self.get_parameter('amplitude_array').get_parameter_value().double_array_value[selection-1]
        frequency = self.get_parameter('frequency_array').get_parameter_value().double_array_value[selection-1] 
        offset = self.get_parameter('offset_array').get_parameter_value().double_array_value[selection-1]

        t = time.time()

        #Calculamos la señal acorde a los parametros establecidos en el momento
        if(selection == 1): #Sine
            self.signal_value.data = amplitude*np.sin(2*np.pi*frequency*t) + offset
        elif(selection == 2): #Square
            self.signal_value.data = amplitude*float(signal.square(2*np.pi*frequency*t)) + offset
        elif(selection  == 3): #Sawtooth
            self.signal_value.data = amplitude*float(signal.sawtooth(2*np.pi*frequency*t)) + offset 
        elif(selection == 4): #Triangle
            self.signal_value.data = amplitude*float(signal.sawtooth(2*np.pi*frequency*t,width=0.5)) + offset
        elif(selection == 5): #Cos
            self.signal_value.data = amplitude*np.cos(2*np.pi*frequency*t) + offset

        #Mostramos valor de la señal
        self.get_logger().info(f"Value: {self.signal_value.data}")

        #Publicamos la señal: 
        self.signal_pub.publish(self.signal_value)

    def send_parameters(self): 
        #Obtenemos los valores de los parametros y los asignamos a cada "atributo" de la variable tipo Parameters: 
        selection = self.get_parameter('selection').get_parameter_value().integer_value
        self.parameters_values.type = selection
        self.parameters_values.amplitude = self.get_parameter('amplitude_array').get_parameter_value().double_array_value[selection-1]
        self.parameters_values.frequency = self.get_parameter('frequency_array').get_parameter_value().double_array_value[selection-1]
        self.parameters_values.offset =  self.get_parameter('offset_array').get_parameter_value().double_array_value[selection-1]
        self.parameters_values.phase_shift = self.get_parameter('phase_shift').get_parameter_value().double_array_value[selection-1]
        self.parameters_values.time = time.time()
        #Pubilcamos los parametros: 
        self.parameters_pub.publish(self.parameters_values)

def main(): 
    #Ejecución del nodo 
    rclpy.init()
    s_g = Signal_Generator()
    rclpy.spin(s_g)
    s_g.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__': 
    main()